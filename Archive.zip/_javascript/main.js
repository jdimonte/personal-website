document.addEventListener('DOMContentLoaded', () => {
  console.log('Hello Bulma!');
});
